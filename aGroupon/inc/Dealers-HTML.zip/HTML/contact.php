<?php
/* include headera */
include_once 'header.php';

?>
















    <!------ CONTENT ------>
    <div class="content">
        <div class="wrapper">

            <div class="content-background">
                <div class="content-wripper">



                    <div class="content-others left">

                        <h1>Contact</h1>


                        <span>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</span>





                        <!--FORM-->
                        <div class="form">
                            <div class="title-border-content left">
                                <h2>Submit a comment</h2>
                            </div><!--/title-border-->

                            <form method="post" action="">
                                <div class="form-content left">
                                    <input style="width: 194px;" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="Name" name="name" />
                                    <input style="width: 194px;" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="Surname" name="surname" />
                                    <input style="margin-right: 0;" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="E-mail Address" name="e-mail" />
                                    <input type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="Company" name="company" />
                                    <input style="margin-right: 0;" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="Website" name="website" />

                                    <textarea onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" name="message">Please enter a detailed description of your product or service as well as its regular price and discounted price:</textarea>
                                </div><!--/form-content-->

                                <div class="form-button">
                                    <a href="#">
                                        <div class="button-send">
                                            <div class="button-send-left left"></div>
                                            <div class="button-send-center left">Send Message</div>
                                            <div class="button-send-right left"></div>
                                        </div>
                                    </a>
                                </div><!--/form-button-->

                            </form>
                        </div><!--/form-->



                    </div><!--/content-others-->








                    <!-- BORDER-HORIZONTAL -->
                    <div class="border-horizontal"></div>




                    <!-- BLOG-SMALL -->
                    <div class="blog-small-home">

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images1.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                        <div class="border-vertical"></div>

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images2.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                        <div class="border-vertical"></div>

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images1.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                    </div><!--blog-small-home-->




                </div><!--content-wripper-->
            </div><!--content-background-->

        </div><!--/wrapper-->
    </div><!--/content-->






















<?php
/* include footer */
include_once 'footer.php';

?>