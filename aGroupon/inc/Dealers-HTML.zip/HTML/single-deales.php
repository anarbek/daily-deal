<?php
/* include headera */
include_once 'header.php';

?>
















    <!------ CONTENT ------>
    <div class="content">
        <div class="wrapper">

            <div class="content-background">
                <div class="content-wripper">



                    <!-- BLOG -->
                    <div class="blog-home">
                        <div class="blog-left">
                            <div class="single-deals-title">This is one very amazing deal</div><!--/title-blog-->
                            <div class="images">
                                <img src="style/img/blog-images.jpg" alt="images" title="images"  />
                            </div><!--/images-->
                            <div class="single-deals-text">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                            </div><!--/text-->
                        </div><!--/blog-left-->

                        <div class="blog-right">
                            <div class="blog-right-text">
                                <span style="padding-top: 22px;">This deal will end in:</span><br />
                                <p style="padding-top: 12px;">6 days 1 hrs 52 min 51 sec</p><br />
                                <span style="padding-top: 25px; margin-bottom: -10px;">Discount</span><br />
                                <h5>43%</h5>
                                <div class="blog-right-dwo">
                                    <span>Deal Value</span><br />
                                    <p style="margin-top: 0;">$47</p>
                                </div><!--blog-right-dwo-->
                                <div class="blog-right-dwo">
                                    <span>You Save</span><br />
                                    <p style="margin-top: 0;">$20</p>
                                </div><!--blog-right-dwo-->

                                <div class="twitter-facebook">NEMOJ DA ZABORAVIS</div>
                            </div><!--blog-right-text-->

                            <div class="blog-right-button">
                                <a href="#">
                                    <div class="button">
                                        <div class="blog-right-left"></div>
                                        <div class="blog-right-center">Buy this deal - 27$</div>
                                        <div class="blog-right-right"></div>
                                    </div>
                                </a><!--/button-->
                            </div><!--/blog-right-button-->
                        </div><!--blog-right-->
                    </div><!--blog-home-->




                    <!-- BORDER-HORIZONTAL -->
                    <div class="border-horizontal"></div>




                    <!-- SPONZORI-LOGO -->
                    <div class="sponzori-logo"></div>




                    <!-- BORDER-HORIZONTAL -->
                    <div class="border-horizontal"></div>




                    <!-- BLOG-SMALL -->
                    <div class="blog-small-home">

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images1.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                        <div class="border-vertical"></div>

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images2.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                        <div class="border-vertical"></div>

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images1.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                    </div><!--blog-small-home-->




                </div><!--content-wripper-->
            </div><!--content-background-->

        </div><!--/wrapper-->
    </div><!--/content-->






















<?php
/* include footer */
include_once 'footer.php';

?>