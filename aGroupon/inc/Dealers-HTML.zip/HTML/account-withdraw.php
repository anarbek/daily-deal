<?php
/* include headera */
include_once 'header.php';

?>
















    <!------ CONTENT ------>
    <div class="content">
        <div class="wrapper">

            <div class="content-background">
                <div class="content-wripper">



                    <div class="content-others left">



                        <div class="my-title-nav left">
                            <div class="my-profile-title left"><h1>Hello, Sinisa Komlenic</h1></div>



                            <!--MENU-->
                            <div class="nav-my-profile right">
                                <ul>
                                    <li style="padding-left: 0px;"><a href="my-profile.php">My profile</a></li>
                                    <li><a href="my-deals.php">My deals</a></li>
                                    <li class="active"><a href="account-withdraw.php">Withdraw earnings</a></li>
                                    <li style="padding-right: 0;"><a href="#">Logout</a></li>
                                </ul>
                            </div><!--/nav-->
                        </div><!--/my-title-nav-->



                        <span>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</span>



                        <div class="account-withdraw-input left">
                            <ul>
                                <li>Amount to withdraw:</li>
                                <li class="withdraw-input-one left"><input type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="$1.845" name="$" /></li>
                                <li class="withdraw-input-two left"><input type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="PayPal Account" name="paypal-account" /></li>
                            </ul>
                            <ul>
                                <div class="form-button">
                                    <a href="#">
                                        <div class="button-send">
                                            <div class="button-send-left left"></div>
                                            <div class="button-send-center left">Submit request</div>
                                            <div class="button-send-right left"></div>
                                        </div>
                                    </a>
                                </div><!--/form-button-->
                            </ul>
                        </div><!--/account-withdraw-input-->


                        



                        <div class="account-withdraw-table left">
                            <TABLE>
                                <TR CLASS="table-one-row">
                                    <TD CLASS="table-one-column" style="width: 142px!important; word-wrap: break-word; text-align: left; padding-left: 20px;">REQUEST DATE</TD>
                                    <TD CLASS="table-one-column" style="width: 106px!important; word-wrap: break-word;">AMOUNT</TD>
                                    <TD CLASS="table-one-column" style="width: 480px!important; text-align: left; padding-left: 20px; word-wrap: break-word; ">TO BE PROCEEDED</TD>
                                    <TD CLASS="table-one-column" style="width: 113px!important; word-wrap: break-word;">STATUS</TD>
                                </TR>
                                <TR>
                                    <TD style="width: 142px!important; text-align: left; padding-left: 20px;">09-06-2011</TD>
                                    <TD>$9844</TD>
                                    <TD style="width: 480px!important; text-align: left; padding-left: 20px;">09-06-2011</TD>
                                    <TD><div CLASS="table-active">Pending</div></TD>
                                </TR>
                            </TABLE>
                        </div>




                    </div><!--/content-others-->








                    <!-- BORDER-HORIZONTAL -->
                    <div class="border-horizontal"></div>




                    <!-- BLOG-SMALL -->
                    <div class="blog-small-home">

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images1.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                        <div class="border-vertical"></div>

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images2.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                        <div class="border-vertical"></div>

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images1.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                    </div><!--blog-small-home-->




                </div><!--content-wripper-->
            </div><!--content-background-->

        </div><!--/wrapper-->
    </div><!--/content-->






















<?php
/* include footer */
include_once 'footer.php';

?>