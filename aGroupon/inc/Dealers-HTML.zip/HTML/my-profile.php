<?php
/* include headera */
include_once 'header.php';

?>
















    <!------ CONTENT ------>
    <div class="content">
        <div class="wrapper">

            <div class="content-background">
                <div class="content-wripper">



                    <div class="content-others left">




                        <div class="my-title-nav left">
                            <div class="my-profile-title left"><h1>Hello, Sinisa Komlenic</h1></div>



                            <!--MENU-->
                            <div class="nav-my-profile right">
                                <ul>
                                    <li class="active" style="padding-left: 0px;"><a href="my-profile.php">My profile</a></li>
                                    <li><a href="my-deals.php">My deals</a></li>
                                    <li><a href="account-withdraw.php">Withdraw earnings</a></li>
                                    <li style="padding-right: 0;"><a href="#">Logout</a></li>
                                </ul>
                            </div><!--/nav-->
                        </div><!--/my-title-nav-->



                        <div class="my-profile-input left">
                            <form method="post" action="">
                                <div class="form-content left">
                                    <input type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="Username" name="username" />
                                    <input style="width: 194px;" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="Password" name="pass" />
                                    <input style="width: 194px; margin-right: 0;" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="Re-type password" name="re-pass" />

                                    <input style="width: 194px;" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="Name" name="name" />
                                    <input style="width: 194px;" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="Surname" name="surname" />
                                    <input style="margin-right: 0;" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="E-mail Address" name="e-mail" />

                                    <input type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="Company" name="company" />
                                    <input style="margin-right: 0;" type="text" onfocus="if(value==defaultValue)value=''" onblur="if(value=='')value=defaultValue" value="Website" name="website" />
                                </div><!--/form-content-->

                                <div class="form-button">
                                    <a href="#">
                                        <div class="button-send">
                                            <div class="button-send-left left"></div>
                                            <div class="button-send-center left">Save changes</div>
                                            <div class="button-send-right left"></div>
                                        </div>
                                    </a>
                                </div><!--/form-button-->

                            </form>
                        </div><!--/content-others-->





                    </div><!--/content-others-->








                    <!-- BORDER-HORIZONTAL -->
                    <div class="border-horizontal"></div>




                    <!-- BLOG-SMALL -->
                    <div class="blog-small-home">

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images1.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                        <div class="border-vertical"></div>

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images2.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                        <div class="border-vertical"></div>

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images1.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                    </div><!--blog-small-home-->




                </div><!--content-wripper-->
            </div><!--content-background-->

        </div><!--/wrapper-->
    </div><!--/content-->






















<?php
/* include footer */
include_once 'footer.php';

?>