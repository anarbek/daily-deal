<?php
/* include headera */
include_once 'header.php';

?>
















    <!------ CONTENT ------>
    <div class="content">
        <div class="wrapper">

            <div class="content-background">
                <div class="content-wripper">



                    <div class="content-others left">



                        <div class="my-title-nav left">
                            <div class="my-profile-title left"><h1>Hello, Sinisa Komlenic</h1></div>



                            <!--MENU-->
                            <div class="nav-my-profile right">
                                <ul>
                                    <li style="padding-left: 0px;"><a href="my-profile.php">My profile</a></li>
                                    <li class="active"><a href="my-deals.php">My deals</a></li>
                                    <li><a href="account-withdraw.php">Withdraw earnings</a></li>
                                    <li style="padding-right: 0;"><a href="#">Logout</a></li>
                                </ul>
                            </div><!--/nav-->
                        </div><!--/my-title-nav-->




                        <div class="my-deals-table left">
                            <TABLE>
                                <TR CLASS="table-one-row">
                                    <TD CLASS="table-one-column" style="width: 165px!important; word-wrap: break-word; text-align: left; padding-left: 20px;">TITLE</TD>
                                    <TD CLASS="table-one-column" style="width: 127px!important; word-wrap: break-word;">START DATE</TD>
                                    <TD CLASS="table-one-column" style="width: 120px!important; word-wrap: break-word;">END DATE</TD>
                                    <TD CLASS="table-one-column" style="width: 121px!important; word-wrap: break-word;">SALES NUM</TD>
                                    <TD CLASS="table-one-column" style="width: 100px!important; word-wrap: break-word;">TOTAL</TD>
                                    <TD CLASS="table-one-column" style="width: 105px!important; word-wrap: break-word;">EARNED</TD>
                                    <TD CLASS="table-one-column" style="width: 113px!important; word-wrap: break-word;">STATUS</TD>
                                </TR>
                                <TR>
                                    <TD>18+ WordPress Themes</TD>
                                    <TD>09-06-2011</TD>
                                    <TD>09-06-2011</TD>
                                    <TD>1256</TD>
                                    <TD>$9844</TD>
                                    <TD>$9844</TD>
                                    <TD><div CLASS="table-active">Active</div></TD>
                                </TR>
                            </TABLE>
                        </div>




                    </div><!--/content-others-->








                    <!-- BORDER-HORIZONTAL -->
                    <div class="border-horizontal"></div>




                    <!-- BLOG-SMALL -->
                    <div class="blog-small-home">

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images1.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                        <div class="border-vertical"></div>

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images2.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                        <div class="border-vertical"></div>

                        <div class="blog-small">
                            <div class="title-blog-small"><a href="blog-post.html">Lorem Ipsum  Dolor Deal</a></div><!--/title-blog-small-->
                            <div class="images-small">
                                <a href="blog-post.html"><img src="style/img/blog-small-images1.jpg" alt="images" title="images"  /></a>
                                <div class="statistic">
                                    <ul>
                                        <li>Deal Value<p>$47</p></li>
                                        <li class="statistic-border"></li>
                                        <li>Discount<p>40%</p></li>
                                        <li class="statistic-border"></li>
                                        <li>You Save<p>$20</p></li>
                                    </ul>
                                </div><!--statistic-->
                            </div><!--/images-small-->
                            <div class="blog-small-button">
                                <p>71 days 23 hrs 38  min36 sec</p>
                                <div class="small-button">
                                    <a href="#">
                                        <div class="button">
                                            <div class="small-left"></div>
                                            <div class="small-center">SEE DEAL</div>
                                            <div class="small-right"></div>
                                        </div>
                                    </a><!--/button-->
                                </div><!--/small-button-->
                            </div><!--/blog-small-button-->
                        </div><!--/blog-small-->

                    </div><!--blog-small-home-->




                </div><!--content-wripper-->
            </div><!--content-background-->

        </div><!--/wrapper-->
    </div><!--/content-->






















<?php
/* include footer */
include_once 'footer.php';

?>